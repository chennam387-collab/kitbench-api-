KITBENCH EMAIL + RAZORPAY BACKEND

WHAT THIS VERSION ADDS
- Keeps student email verification routes.
- Adds /api/create-order and /api/verify-payment for Razorpay.
- Adds /api/orders/cod for cash-on-delivery orders.
- Calculates prices from the server-side catalog.json; browser-submitted prices are not trusted.
- Sends order confirmation emails after verified online payments and COD order placement.

DEPLOY
1. Replace the backend repository files with the contents of this folder.
2. In Render, set Root Directory to the folder containing server.js (usually the repo root), then deploy.
3. Add the environment variables listed in .env.example to Render. Do not put RAZORPAY_KEY_SECRET or email API keys in HTML/GitHub.
4. For email, create a Brevo or Resend account, verify the sender address/domain required by that provider, then set MAIL_PROVIDER, its API key, and MAIL_FROM_EMAIL in Render.
5. For Razorpay testing, use the matching Test Mode Key ID and Key Secret from the same Razorpay account. The frontend's current key ID is rzp_test_ToGKKXdbV8RgND; confirm it belongs to your account and use its matching secret, or replace the frontend key ID with your own test Key ID.
6. The frontend calls https://kitbench-api.onrender.com. Ensure this is the Render URL for the deployed service, and ALLOWED_ORIGINS includes https://chennam387-collab.github.io (origin only, no /kitbench-api-/ path).
7. Test student signup/email verification, COD order, then Razorpay Test Mode before using live keys. Never share secrets in chat or commit them to GitHub.

IMPORTANT
- SQLite data can be lost on some redeploys/host restarts unless you configure persistent storage. Configure a persistent disk/path for DB_PATH before real orders, or migrate to a managed database.
- This code does not store card details. Razorpay Checkout handles payment details.
- Email delivery depends on valid provider credentials and a verified sender.
