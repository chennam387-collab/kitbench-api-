'use strict';
// Sends email over HTTPS (not SMTP). As far as I know, Render's free tier blocks SMTP ports, so use an email API.
// MAIL_PROVIDER=brevo  -> BREVO_API_KEY   (you verify one sender address)
// MAIL_PROVIDER=resend -> RESEND_API_KEY  (you verify a domain to email anyone)
const FROM_EMAIL = process.env.MAIL_FROM_EMAIL || '';
const FROM_NAME = process.env.MAIL_FROM_NAME || 'KitBench';

async function post(url, headers, body) {
  const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error('Email provider error ' + res.status + ': ' + (await res.text()).slice(0, 200));
}

async function sendMail({ to, subject, html, text }) {
  const provider = (process.env.MAIL_PROVIDER || 'brevo').toLowerCase();
  if (!FROM_EMAIL) throw new Error('MAIL_FROM_EMAIL is not set');
  if (provider === 'resend') {
    if (!process.env.RESEND_API_KEY) throw new Error('RESEND_API_KEY is not set');
    return post('https://api.resend.com/emails', { Authorization: 'Bearer ' + process.env.RESEND_API_KEY },
      { from: `${FROM_NAME} <${FROM_EMAIL}>`, to: [to], subject, html, text });
  }
  if (provider === 'brevo') {
    if (!process.env.BREVO_API_KEY) throw new Error('BREVO_API_KEY is not set');
    return post('https://api.brevo.com/v3/smtp/email', { 'api-key': process.env.BREVO_API_KEY, accept: 'application/json' },
      { sender: { name: FROM_NAME, email: FROM_EMAIL }, to: [{ email: to }], subject, htmlContent: html, textContent: text });
  }
  throw new Error('Unknown MAIL_PROVIDER: ' + provider);
}

module.exports = { sendMail };
