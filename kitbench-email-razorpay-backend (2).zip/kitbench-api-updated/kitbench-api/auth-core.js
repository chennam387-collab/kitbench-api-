'use strict';
// Pure helpers for email verification. No database, no network: easy to test.
const crypto = require('crypto');

const CODE_TTL_MS = 10 * 60 * 1000;      // a code works for 10 minutes
const MAX_ATTEMPTS = 5;                   // wrong guesses allowed per code
const RESEND_COOLDOWN_MS = 60 * 1000;     // wait before sending another code
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const normEmail = (v) => String(v == null ? '' : v).trim().toLowerCase().slice(0, 254);
const validEmail = (e) => e.length > 0 && e.length <= 254 && EMAIL_RE.test(e);
const newCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');

// The code is stored only as a keyed hash, never in plain text.
const hashCode = (code, email, secret) =>
  crypto.createHmac('sha256', secret).update(email + ':' + code).digest('hex');

function hashesMatch(a, b) {
  const x = Buffer.from(String(a), 'hex');
  const y = Buffer.from(String(b), 'hex');
  return x.length > 0 && x.length === y.length && crypto.timingSafeEqual(x, y);
}

// record: { codeHash, codeExpires (ms), attempts }. The caller adds 1 to attempts when reason is 'wrong'.
function checkCode({ record, code, email, secret, now }) {
  if (!record || !record.codeHash) return { ok: false, reason: 'none' };
  if ((record.attempts || 0) >= MAX_ATTEMPTS) return { ok: false, reason: 'locked' };
  if (now > record.codeExpires) return { ok: false, reason: 'expired' };
  if (!/^\d{6}$/.test(String(code))) return { ok: false, reason: 'wrong' };
  return hashesMatch(record.codeHash, hashCode(String(code), email, secret))
    ? { ok: true }
    : { ok: false, reason: 'wrong' };
}

function validateRegistration(b) {
  const name = String(b.name || '').trim();
  const city = String(b.city || '').trim();
  const email = normEmail(b.email);
  const password = String(b.password || '');
  if (!name || name.length > 80) return { error: 'Please enter your full name.' };
  if (!validEmail(email)) return { error: 'Please enter a valid email address.' };
  if (password.length < 8 || password.length > 72) return { error: 'Password must be 8 to 72 characters.' };
  if (b.confirmPassword != null && String(b.confirmPassword) !== password) return { error: 'Passwords do not match.' };
  if (city.length > 80) return { error: 'Location is too long.' };
  return { value: { name, email, password, city } };
}

const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function verificationEmail(name, code) {
  const subject = 'Your KitBench verification code: ' + code;
  const text = `Hi ${name},\n\nYour KitBench verification code is ${code}.\nIt expires in 10 minutes. If you did not sign up, you can ignore this email.\n`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:480px"><h2>Verify your email</h2><p>Hi ${esc(name)}, use this code to finish creating your KitBench account:</p><p style="font-size:32px;letter-spacing:8px;font-weight:700">${esc(code)}</p><p>It expires in 10 minutes. If you did not sign up, you can ignore this email.</p></div>`;
  return { subject, text, html };
}

module.exports = { CODE_TTL_MS, MAX_ATTEMPTS, RESEND_COOLDOWN_MS, normEmail, validEmail, newCode, hashCode, checkCode, validateRegistration, verificationEmail };
