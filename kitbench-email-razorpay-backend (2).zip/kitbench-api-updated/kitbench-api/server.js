'use strict';
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const { sendMail } = require('./mailer');

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '20kb' }));
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
app.use(cors({ origin: (origin, cb) => cb(null, !origin || allowed.includes(origin)) }));

const db = new Database(process.env.DB_PATH || './kitbench.db');
db.exec(`CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, razorpay_order_id TEXT UNIQUE, payment_id TEXT,
  amount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'INR', status TEXT NOT NULL,
  customer_name TEXT NOT NULL, customer_email TEXT NOT NULL, customer_phone TEXT NOT NULL,
  customer_address TEXT NOT NULL, items_json TEXT NOT NULL, created_at INTEGER NOT NULL,
  paid_at INTEGER
)`);
const catalog = require('./catalog.json');
const productById = new Map(catalog.map((p) => [p.id, p]));
const orderById = db.prepare('SELECT * FROM orders WHERE id = ?');
const orderByRzpId = db.prepare('SELECT * FROM orders WHERE razorpay_order_id = ?');
const saveOrder = db.prepare(`INSERT INTO orders
  (id, razorpay_order_id, payment_id, amount, currency, status, customer_name, customer_email, customer_phone, customer_address, items_json, created_at, paid_at)
  VALUES (@id, @razorpay_order_id, @payment_id, @amount, @currency, @status, @customer_name, @customer_email, @customer_phone, @customer_address, @items_json, @created_at, @paid_at)`);
const markPaid = db.prepare("UPDATE orders SET payment_id=?, status='paid', paid_at=? WHERE id=? AND status='pending'");

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/api', require('./auth-email'));

function validateCustomer(value) {
  const c = value || {};
  const name = String(c.name || '').trim();
  const email = String(c.email || '').trim().toLowerCase();
  const phone = String(c.phone || '').trim();
  const address = String(c.address || '').trim();
  if (!name || name.length > 100) throw new Error('Enter a valid full name.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 254) throw new Error('Enter a valid email address.');
  if (!/^[0-9+ ()-]{10,18}$/.test(phone)) throw new Error('Enter a valid phone number.');
  if (!address || address.length > 1000) throw new Error('Enter a valid delivery address.');
  return { name, email, phone, address };
}
function validateItems(value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 30) throw new Error('Your cart is empty or has too many items.');
  const quantities = new Map();
  for (const row of value) {
    const id = String((row && row.id) || '');
    const quantity = Number(row && row.quantity);
    if (!productById.has(id) || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) throw new Error('One or more cart items are invalid.');
    quantities.set(id, (quantities.get(id) || 0) + quantity);
    if (quantities.get(id) > 10) throw new Error('Maximum quantity per kit is 10.');
  }
  const items = Array.from(quantities, ([id, quantity]) => ({ ...productById.get(id), quantity }));
  const totalRupees = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  if (!Number.isSafeInteger(totalRupees) || totalRupees < 1 || totalRupees > 500000) throw new Error('Order total is outside the allowed range.');
  return { items, totalRupees, amountPaise: totalRupees * 100 };
}
function razorpayConfig() {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) throw new Error('Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to the backend environment.');
  return { keyId, keySecret };
}
async function razorpayRequest(path, method, body) {
  const { keyId, keySecret } = razorpayConfig();
  const response = await fetch('https://api.razorpay.com/v1' + path, {
    method,
    headers: {
      Authorization: 'Basic ' + Buffer.from(keyId + ':' + keySecret).toString('base64'),
      'Content-Type': 'application/json'
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
    signal: AbortSignal.timeout(15000)
  });
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = {}; }
  if (!response.ok) {
    const message = data && data.error && data.error.description;
    throw new Error(message || 'Razorpay request failed (' + response.status + ').');
  }
  return data;
}
function safeEqualHex(a, b) {
  if (!/^[a-f0-9]+$/i.test(String(a || '')) || !/^[a-f0-9]+$/i.test(String(b || ''))) return false;
  const x = Buffer.from(String(a), 'hex');
  const y = Buffer.from(String(b), 'hex');
  return x.length === y.length && x.length > 0 && crypto.timingSafeEqual(x, y);
}
function emailEscape(v) { return String(v).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
async function sendOrderEmail(order, paid) {
  const items = JSON.parse(order.items_json);
  const list = items.map(i => `<li>${emailEscape(i.title)} × ${i.quantity} — ₹${(i.price * i.quantity).toLocaleString('en-IN')}</li>`).join('');
  const total = (order.amount / 100).toLocaleString('en-IN');
  const subject = paid ? `KitBench payment confirmed — ${order.id}` : `KitBench order received — ${order.id}`;
  const text = `Hi ${order.customer_name},\n\n${paid ? 'Your payment is verified.' : 'Your cash-on-delivery order has been placed.'}\nOrder: ${order.id}\nItems:\n${items.map(i => `${i.title} x ${i.quantity}`).join('\n')}\nTotal: INR ${total}\n${paid ? 'Payment ID: ' + order.payment_id : 'Payment method: Cash on delivery'}\n\nThank you for shopping with KitBench.`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#17202a"><h2>${paid ? 'Payment confirmed' : 'Order received'}</h2><p>Hi ${emailEscape(order.customer_name)},</p><p>${paid ? 'Your payment has been verified successfully.' : 'Your cash-on-delivery order has been placed.'}</p><p><b>Order:</b> ${emailEscape(order.id)}</p><ul>${list}</ul><p><b>Total:</b> ₹${total}</p><p>${paid ? '<b>Payment ID:</b> ' + emailEscape(order.payment_id || '') : '<b>Payment method:</b> Cash on delivery'}</p><p>Thank you for shopping with KitBench.</p></div>`;
  await sendMail({ to: order.customer_email, subject, text, html });
}
function makeOrderId(prefix) { return prefix + '-' + crypto.randomUUID().slice(0, 8).toUpperCase(); }

app.post('/api/create-order', async (req, res) => {
  try {
    const customer = validateCustomer(req.body && req.body.customer);
    const { items, totalRupees, amountPaise } = validateItems(req.body && req.body.items);
    const id = makeOrderId('KB');
    const rzpOrder = await razorpayRequest('/orders', 'POST', {
      amount: amountPaise, currency: 'INR', receipt: id,
      notes: { kitbench_order: id, customer_email: customer.email }
    });
    saveOrder.run({ id, razorpay_order_id: rzpOrder.id, payment_id: null, amount: amountPaise, currency: 'INR', status: 'pending', customer_name: customer.name, customer_email: customer.email, customer_phone: customer.phone, customer_address: customer.address, items_json: JSON.stringify(items), created_at: Date.now(), paid_at: null });
    res.json({ id: rzpOrder.id, amount: amountPaise, currency: 'INR', receipt: id, total: totalRupees });
  } catch (err) {
    const clientError = /valid|empty|quantity|allowed range|cart|Razorpay is not configured|delivery address|phone number|email address|full name/i.test(err.message || '');
    res.status(clientError ? 400 : 502).json({ error: err.message || 'Could not create payment order.' });
  }
});

app.post('/api/verify-payment', async (req, res) => {
  try {
    const body = req.body || {};
    const orderId = String(body.razorpay_order_id || '');
    const paymentId = String(body.razorpay_payment_id || '');
    const signature = String(body.razorpay_signature || '');
    const order = orderByRzpId.get(orderId);
    if (!order || !paymentId || !signature) return res.status(400).json({ verified: false, error: 'Payment details are incomplete or the order was not found.' });
    if (order.status === 'paid' && order.payment_id === paymentId) return res.json({ verified: true, orderId: order.id });
    const { keySecret } = razorpayConfig();
    const expected = crypto.createHmac('sha256', keySecret).update(orderId + '|' + paymentId).digest('hex');
    if (!safeEqualHex(expected, signature)) return res.status(400).json({ verified: false, error: 'Payment signature did not match.' });
    const payment = await razorpayRequest('/payments/' + encodeURIComponent(paymentId), 'GET');
    if (payment.order_id !== orderId || payment.amount !== order.amount || payment.currency !== order.currency || payment.status !== 'captured') {
      return res.status(400).json({ verified: false, error: 'Razorpay has not confirmed a captured payment for this order yet.' });
    }
    markPaid.run(paymentId, Date.now(), order.id);
    const updated = orderById.get(order.id);
    try { await sendOrderEmail(updated, true); } catch (e) { console.error('Payment confirmation email failed:', e.message); }
    res.json({ verified: true, orderId: order.id });
  } catch (err) {
    console.error('Payment verification failed:', err.message);
    res.status(502).json({ verified: false, error: 'Could not verify payment with Razorpay. Please contact KitBench support before paying again.' });
  }
});

app.post('/api/orders/cod', async (req, res) => {
  try {
    const customer = validateCustomer(req.body && req.body.customer);
    const { items, totalRupees, amountPaise } = validateItems(req.body && req.body.items);
    if (totalRupees > 20000) return res.status(400).json({ error: 'Cash on delivery is available only for orders up to ₹20,000.' });
    const id = makeOrderId('KB-COD');
    saveOrder.run({ id, razorpay_order_id: null, payment_id: null, amount: amountPaise, currency: 'INR', status: 'cod_placed', customer_name: customer.name, customer_email: customer.email, customer_phone: customer.phone, customer_address: customer.address, items_json: JSON.stringify(items), created_at: Date.now(), paid_at: null });
    const order = orderById.get(id);
    try { await sendOrderEmail(order, false); } catch (e) { console.error('COD confirmation email failed:', e.message); }
    res.json({ ok: true, ref: id, total: totalRupees });
  } catch (err) {
    const clientError = /valid|empty|quantity|allowed range|cart|delivery address|phone number|email address|full name/i.test(err.message || '');
    res.status(clientError ? 400 : 500).json({ error: err.message || 'Could not place the order.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('KitBench API listening on ' + port));
