'use strict';
const assert = require('assert');
const c = require('./auth-core');
const S = 'test-secret', email = 'a@b.com', now = 1_000_000;
const code = c.newCode(); assert(/^\d{6}$/.test(code));
const rec = { codeHash: c.hashCode(code, email, S), codeExpires: now + c.CODE_TTL_MS, attempts: 0 };
assert.deepStrictEqual(c.checkCode({ record: rec, code, email, secret: S, now }), { ok: true });
assert.strictEqual(c.checkCode({ record: rec, code: code === '000000' ? '111111' : '000000', email, secret: S, now }).reason, 'wrong');
assert.strictEqual(c.checkCode({ record: rec, code, email: 'x@y.com', secret: S, now }).reason, 'wrong');          // code is tied to the email
assert.strictEqual(c.checkCode({ record: rec, code, email, secret: S, now: now + c.CODE_TTL_MS + 1 }).reason, 'expired');
assert.strictEqual(c.checkCode({ record: { ...rec, attempts: c.MAX_ATTEMPTS }, code, email, secret: S, now }).reason, 'locked');
assert.strictEqual(c.checkCode({ record: null, code, email, secret: S, now }).reason, 'none');
assert.strictEqual(c.checkCode({ record: rec, code: '12ab56', email, secret: S, now }).reason, 'wrong');
assert.strictEqual(c.checkCode({ record: rec, code, email, secret: 'other', now }).reason, 'wrong');
assert.strictEqual(c.validateRegistration({ name: 'A', email: 'bad', password: 'password1' }).error, 'Please enter a valid email address.');
assert.strictEqual(c.validateRegistration({ name: 'A', email: 'a@b.co', password: 'short' }).error, 'Password must be 8 to 72 characters.');
assert.strictEqual(c.validateRegistration({ name: 'A', email: 'a@b.co', password: 'password1', confirmPassword: 'password2' }).error, 'Passwords do not match.');
const ok = c.validateRegistration({ name: ' Ravi ', email: ' RAVI@Example.COM ', password: 'password1', confirmPassword: 'password1', city: 'Hyderabad' });
assert.deepStrictEqual(ok.value, { name: 'Ravi', email: 'ravi@example.com', password: 'password1', city: 'Hyderabad' });
assert(!c.verificationEmail('<b>x</b>', '123456').html.includes('<b>x</b>'));                                       // names are escaped in the email
const seen = new Set(); for (let i = 0; i < 2000; i++) seen.add(c.newCode()); assert(seen.size > 1500);
console.log('auth-core: all checks passed');
