'use strict';
// Auth routes with email verification. Mount at /api (see server.js).
// Storage is SQLite for simplicity. On Render a SQLite file is erased on every redeploy unless you attach a
// persistent disk, so for real use swap the few db.prepare(...) calls for your own database.
const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const core = require('./auth-core');
const { sendMail } = require('./mailer');

const CODE_SECRET = process.env.CODE_SECRET;
const JWT_SECRET = process.env.JWT_SECRET;
if (!CODE_SECRET || !JWT_SECRET) throw new Error('Set CODE_SECRET and JWT_SECRET (long random strings).');

const db = new Database(process.env.DB_PATH || './kitbench.db');
db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, city TEXT DEFAULT '',
  pass_hash TEXT NOT NULL, verified INTEGER NOT NULL DEFAULT 0,
  code_hash TEXT, code_expires INTEGER, attempts INTEGER NOT NULL DEFAULT 0, last_code_sent INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL)`);

const byEmail = db.prepare('SELECT * FROM users WHERE email = ?');
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12); // keeps login timing the same for unknown emails

async function issueCode(email, name) {
  const code = core.newCode(), now = Date.now();
  db.prepare('UPDATE users SET code_hash=?, code_expires=?, attempts=0, last_code_sent=? WHERE email=?')
    .run(core.hashCode(code, email, CODE_SECRET), now + core.CODE_TTL_MS, now, email);
  await sendMail({ to: email, ...core.verificationEmail(name, code) });
}

const router = express.Router();
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Please try again later.' } });
const resendLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many code requests. Please try again in an hour.' } });
router.use('/auth', authLimiter);

router.post('/auth/register', async (req, res) => {
  const v = core.validateRegistration(req.body || {});
  if (v.error) return res.status(400).json({ error: v.error });
  const { name, email, password, city } = v.value;
  const existing = byEmail.get(email);
  if (existing && existing.verified) return res.status(409).json({ error: 'This email is already registered. Please log in.' });
  if (existing && Date.now() - existing.last_code_sent < core.RESEND_COOLDOWN_MS)
    return res.status(429).json({ error: 'A code was just sent. Please wait a minute before trying again.' });
  const passHash = await bcrypt.hash(password, 12);
  if (existing) db.prepare('UPDATE users SET name=?, city=?, pass_hash=? WHERE email=?').run(name, city, passHash, email);
  else db.prepare('INSERT INTO users (email,name,city,pass_hash,created_at) VALUES (?,?,?,?,?)').run(email, name, city, passHash, Date.now());
  try { await issueCode(email, name); }
  catch (e) { console.error('verification email failed:', e.message); return res.status(502).json({ error: 'We could not send the verification email. Please try again later.' }); }
  res.json({ ok: true, verified: false });
});

router.post('/auth/verify-email', (req, res) => {
  const email = core.normEmail(req.body && req.body.email), code = String((req.body && req.body.code) || '').trim();
  const row = byEmail.get(email);
  if (!row) return res.status(400).json({ error: 'Invalid or expired code.' });
  if (row.verified) return res.json({ ok: true, verified: true });
  const r = core.checkCode({ record: { codeHash: row.code_hash, codeExpires: row.code_expires, attempts: row.attempts }, code, email, secret: CODE_SECRET, now: Date.now() });
  if (!r.ok) {
    if (r.reason === 'wrong') db.prepare('UPDATE users SET attempts = attempts + 1 WHERE email=?').run(email);
    const msg = { locked: 'Too many wrong attempts. Please request a new code.', expired: 'This code has expired. Please request a new one.', wrong: 'That code is not correct.', none: 'Invalid or expired code.' }[r.reason];
    return res.status(r.reason === 'locked' ? 429 : 400).json({ error: msg });
  }
  db.prepare('UPDATE users SET verified=1, code_hash=NULL, code_expires=NULL, attempts=0 WHERE email=?').run(email);
  res.json({ ok: true, verified: true });
});

router.post('/auth/resend-code', resendLimiter, async (req, res) => {
  const email = core.normEmail(req.body && req.body.email);
  const row = core.validEmail(email) ? byEmail.get(email) : null;
  // Same answer whether or not the email exists, so this cannot be used to find out who has an account.
  if (!row || row.verified) return res.json({ ok: true });
  if (Date.now() - row.last_code_sent < core.RESEND_COOLDOWN_MS) return res.status(429).json({ error: 'Please wait a minute before asking for another code.' });
  try { await issueCode(email, row.name); }
  catch (e) { console.error('resend email failed:', e.message); return res.status(502).json({ error: 'We could not send the email. Please try again later.' }); }
  res.json({ ok: true });
});

router.post('/auth/login', async (req, res) => {
  const email = core.normEmail(req.body && req.body.email), password = String((req.body && req.body.password) || '');
  const row = byEmail.get(email);
  const ok = await bcrypt.compare(password, row ? row.pass_hash : DUMMY_HASH);
  if (!row || !ok) return res.status(401).json({ error: 'Invalid email or password.' });
  if (!row.verified) return res.status(403).json({ error: 'Please verify your email first.', needsVerification: true });
  const token = jwt.sign({ sub: row.id, email: row.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { name: row.name, email: row.email, city: row.city || '' } });
});

// Member count shown on the KitBench home page. Counts verified students only.
router.get('/stats/users', (req, res) => {
  res.set('Cache-Control', 'public, max-age=300');
  res.json({ count: db.prepare('SELECT COUNT(*) AS n FROM users WHERE verified = 1').get().n });
});

module.exports = router;
